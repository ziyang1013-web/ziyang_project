#ifndef __light_H
#define __light_H

void light_Init(void);
void light1_ON(void);
void light1_OFF(void);
void light1_Turn(void);
void light2_ON(void);
void light2_OFF(void);
void light2_Turn(void);
void light3_ON(void);
void light3_OFF(void);
void light3_Turn(void);
void light4_ON(void);
void light4_OFF(void);
void light4_Turn(void);


#endif
