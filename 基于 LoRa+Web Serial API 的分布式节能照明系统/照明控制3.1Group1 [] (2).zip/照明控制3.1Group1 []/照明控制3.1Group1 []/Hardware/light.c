#include "stm32f10x.h"                  // Device header

/**
  * 函    数：LED初始化
  * 参    数：无
  * 返 回 值：无
  */
void light_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						//将PA1和PA2引脚初始化为推挽输出
	
	/*设置GPIO初始化后的默认电平*/
	GPIO_SetBits(GPIOA, GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);				//设置PA2PA3PA4PA5引脚为高电平
}

/**
  * 函    数：LED1关闭
  * 参    数：无
  * 返 回 值：无
  */
void light1_OFF(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_2);		//设置PA2引脚为低电平
}

/**
  * 函    数：LED1开启
  * 参    数：无
  * 返 回 值：无
  */
void light1_ON(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_2);		//设置PA2引脚为高电平
}

/**
  * 函    数：LED1状态翻转
  * 参    数：无
  * 返 回 值：无
  */
void light1_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_2) == 0)		//获取输出寄存器的状态，如果当前引脚输出低电平
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_2);					//则设置PA2引脚为高电平
	}
	else													//否则，即当前引脚输出高电平
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_2);					//则设置PA2引脚为低电平
	}
}

/**
  * 函    数：LED2关闭
  * 参    数：无
  * 返 回 值：无
  */
void light2_OFF(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_3);		//设置PA3引脚为低电平
}

/**
  * 函    数：LED2开启
  * 参    数：无
  * 返 回 值：无
  */
void light2_ON(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_3);		//设置PA3引脚为高电平
}

/**
  * 函    数：LED2状态翻转
  * 参    数：无
  * 返 回 值：无
  */
void light2_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_3) == 0)		//获取输出寄存器的状态，如果当前引脚输出低电平
	{                                                  
		GPIO_SetBits(GPIOA, GPIO_Pin_3);               		//则设置PA3引脚为高电平
	}                                                  
	else                                               		//否则，即当前引脚输出高电平
	{                                                  
		GPIO_ResetBits(GPIOA, GPIO_Pin_3);             		//则设置PA3引脚为低电平
	}
}

/**
  * 函    数：LED3关闭
  * 参    数：无
  * 返 回 值：无
  */
void light3_OFF(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_4);		//设置PA4引脚为低电平
}

/**
  * 函    数：LED3开启
  * 参    数：无
  * 返 回 值：无
  */
void light3_ON(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_4);		//设置PA4引脚为高电平
}

/**
  * 函    数：LED3状态翻转
  * 参    数：无
  * 返 回 值：无
  */
void light3_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_4) == 0)		//获取输出寄存器的状态，如果当前引脚输出低电平
	{                                                  
		GPIO_SetBits(GPIOA, GPIO_Pin_4);               		//则设置PA4引脚为高电平
	}                                                  
	else                                               		//否则，即当前引脚输出高电平
	{                                                  
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);             		//则设置PA4引脚为低电平
	}
}

/**
  * 函    数：LED4关闭
  * 参    数：无
  * 返 回 值：无
  */
void light4_OFF(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_5);		//设置PA4引脚为低电平
}

/**
  * 函    数：LED4开启
  * 参    数：无
  * 返 回 值：无
  */
void light4_ON(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_5);		//设置PA5引脚为高电平
}

/**
  * 函    数：LED4状态翻转
  * 参    数：无
  * 返 回 值：无
  */
void light4_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_5) == 0)		//获取输出寄存器的状态，如果当前引脚输出低电平
	{                                                  
		GPIO_SetBits(GPIOA, GPIO_Pin_5);               		//则设置PA5引脚为高电平
	}                                                  
	else                                               		//否则，即当前引脚输出高电平
	{                                                  
		GPIO_ResetBits(GPIOA, GPIO_Pin_5);             		//则设置PA5引脚为低电平
	}
}


