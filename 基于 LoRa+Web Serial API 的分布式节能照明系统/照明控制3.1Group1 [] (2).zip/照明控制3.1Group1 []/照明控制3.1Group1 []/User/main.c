
#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "light.h"
#include "Key.h"
#include "string.h"
#include "AD.h"
#include <math.h>
#include <stdlib.h>

  uint8_t mode=1;
	uint8_t Keynum;
  uint8_t No=2;                           //自身地址变量
  uint8_t Group=1;                        //分组地址变量
	uint8_t gear=2;
	uint8_t run=0;
	uint8_t run2=0;
	uint8_t run3=0;
	uint8_t x=0;
	uint8_t y=0;
	//添加：
	void Process_Led_Turn(void);
	uint8_t led_turn_num=0;
	//
	uint16_t light1;
	uint16_t light2=2100;
	uint16_t light2string[10]={1000};

	uint16_t average_light;
	uint32_t Num_of_people;
	uint16_t light1s=500;
	uint16_t light2s=2000;
	uint16_t light3s=3600;
	uint32_t Num_of_people1s=20000;
	uint32_t Num_of_people2s=35000;
	uint32_t Num_of_people3s=50000;
	
	
int main(void)
{
	OLED_Init();		//OLED初始化
	light_Init();			//LED初始化
	Serial_Init();		//串口初始化
	Key_Init();    //按键初始化
	AD_Init();					//AD初始化
	
	
	OLED_ShowNum(1, 4, No,1);
	OLED_ShowNum(1, 13, Group,1);
	OLED_ShowString(1, 1, "No:");
	OLED_ShowString(1, 6, "Group:");
	OLED_ShowString(2, 1, "light:");
	OLED_ShowString(3, 1, "aver_light:");

	while (1)
	{
 	  OLED_ShowNum(4, 13, mode,1);
		Keynum=Key_GetNum();
		if(Keynum==1)
		{
			mode=1-mode;
			
		}
		
		
		//*****************光敏/照度档位采集、发送*******************************
     light1=4100-AD_Value[0];
		 OLED_ShowNum(2,7,light1,4);
		 Delay_ms(100);							//延时100ms，手动增加一些转换的间隔时间
		 average_light=(light1+light2)/2;
     OLED_ShowNum(3,12,average_light,4);
			printf("[node,%01d,%04d]",No,2000);   
     //printf("[node,%01d,%04d]",No,light1);     //***************************************************
		 Delay_ms(100);
		
		
		 if (Serial_RxFlag == 1)      //*********************************************当有指令发来**************************
		{ 
/////////

////////
			char *Tag = strtok(Serial_RxPacket, ",");    
		 			
			if (strcmp(Tag, "node") == 0)      //光敏采集、解析、计算.........................
			{
				char *Which = strtok(NULL, ",");
				char *Value = strtok(NULL, ",");
				uint8_t nodeNo = atoi(Which);
				uint16_t nodelight = atoi(Value);			
				for(y=0;y<10;y++){light2string[y]=nodelight;}
				
			 uint32_t sum=0;
		   uint8_t i=0;
		   uint16_t aver;
		   for(i=0;i<10;i++)
		   {
			 sum+=light2string[i];
		   }
		   light2=sum/10;
				

			}		 
		 //Delay_s(1);	
		//**************************照度档位确定**************************************
		if(gear==1)
      {	
				if(gear!=run){
			light1_ON();light2_OFF();light3_OFF();light4_OFF();
				  printf("[gear1,No:%02d]",No);
					OLED_ShowString(4, 1, "gear1");
				}
				run=1;
			}
		else if(gear==2)
      {
				if(gear!=run){
			light1_ON();light2_ON();light3_OFF();light4_OFF();
			printf("[gear2,No:%02d]",No);
				OLED_ShowString(4, 1, "gear2");	}
        run=2;				
			}
		else if(gear==3)
      {
				if(gear!=run){
			light1_ON();light2_ON();light3_ON();light4_OFF();
				printf("[gear3,No:%02d]",No);
				OLED_ShowString(4, 1, "gear3");	}	
            run=3;				
			}
		else if(gear==4)
      {
				if(gear!=run){
			light1_ON();light2_ON();light3_ON();light4_ON();
				printf("[gear4,No:%02d]",No);
				OLED_ShowString(4, 1, "gear4");}
				run=4;
			}
			else if(gear==5)
      {
				if(gear!=run){
				light1_OFF();light2_OFF();light3_OFF();light4_OFF();
				printf("[gear0,No:%02d]",No);
				OLED_ShowString(4, 1, "gear0");}
				run=5;
			}
			if(mode!=run2)
			{
				printf("[mode,%01d,%02d]",mode,No);
				run2=mode;
			}
			
		//**************************前端控制**************************8		
   if(mode==1)
		 {
			 
      
			if (average_light<light1s)		//如果当前光强输出小于于第一档
		  {			  
				gear=1;
							
			}

		  else if(average_light>light1s&&average_light<=light2s)
			{			
				gear=2;
				
			}
			else if(average_light>light2s&&average_light<=light3s)
			{
				gear=3;
				
			}
			else if(average_light>light3s)
			{
				gear=4;
				
		  }
	   }
	 

			
			//Serial_RxFlag = 0;
      if (strcmp(Tag, "mode") == 0)     //模式切换
      {
				char *Which = strtok(NULL, ",");
				if (strcmp(Which, "0") == 0 )   
				{
					mode = 0;
				}
				else if (strcmp(Which, "1") == 0 )   
				{
					mode = 1;
				}
			}
			
//***********************主控制*******************************************				
		if(mode==0)//手动模式
		{
			Process_Led_Turn();//切换灯的状态
			if (strcmp(Tag, "gear") == 0)      //档位控制判断.........................
			{ 
				char *Which = strtok(NULL, ",");
				char *How = strtok(NULL, ",");
				uint8_t Which1 = atoi(Which);
				if (strcmp(Which, "0") == 0 )   //Which=0即为总体控制
				{
					gear = atoi(How);
				}
				else if(strcmp(Which, "0") != 0 )
				{
				 if(Which1 == No)   //Which1=No即为控制相应节点
				 {
					gear = atoi(How);
				 }
			  }
		  }
		}
					if (strcmp(Tag, "allledon") == 0)
					{
							gear = 4;
							// 立即点亮所有灯，避免等待 gear 判断
					}
					else if (strcmp(Tag, "allledoff") == 0)
					{
							gear = 5;

					}
			Serial_RxFlag = 0;
		}
		
		
	}
			
	
}
	
		
	
void Process_Led_Turn(void)//切换灯的状态
{
    if (led_turn_num == 1)
    {
        light1_Turn();
        led_turn_num = 0;
    }
    else if (led_turn_num == 2)
    {
        light2_Turn();
        led_turn_num = 0;
    }
    else if (led_turn_num == 3)
    {
        light3_Turn();
        led_turn_num = 0;
    }
    else if (led_turn_num == 4)
    {
        light4_Turn();
        led_turn_num = 0;
    }
}





























